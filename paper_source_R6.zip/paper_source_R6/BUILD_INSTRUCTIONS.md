# Editable paper source

This source package contains the R6 manuscript, supplement, bibliography and current ACM class/style. R5 is preserved separately and is not required to edit or build this copy.

1. Use a server with Python 3 and a current TeX/ACM setup (acmart 2.21).
2. Run `python3 build_tex.py` from this directory.
3. Compile `latex/paper.tex`; the recorded build used `tectonic --only-cached --keep-logs paper.tex` from `latex/` with an existing resource cache. A fresh installation needs the normal TeX dependencies/resources first. The compiler binary/cache is not included.
4. Inspect the resulting PDF and confirm the ASIACCS 12-main/10-extra limits, Open Science and ethics lengths. Insert only a verified anonymous artifact URL before submission, then rebuild and inspect again.

The artifact bundle, rather than this writing package, supplies saved-record numerical verifiers. No model/API calls are needed for writing or offline verification. Source support remains author/AI inspection. Do not interpret an unrun optional experiment as evidence.
