from pathlib import Path
import re,json,shutil
P=Path(__file__).resolve().parent;O=P/'latex';O.mkdir(exist_ok=True)
keys=set(json.loads((P/'reference_order.json').read_text()))
def esc(s):
 s=s.replace('–','--').replace('—','---').replace('−','-').replace('×',r'\(\times\)').replace('≥',r'\(\geq\)')
 repl={'/':r'\slash\allowbreak{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_\allowbreak{}','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}
 # Unicode math substitutions are applied after escaping.
 s=s.replace(r'\(\times\)','XMULTX').replace(r'\(\geq\)','XGEQX')
 return ''.join(repl.get(c,c) for c in s).replace('XMULTX',r'\(\times\)').replace('XGEQX',r'\(\geq\)')
def inline(s):
 parts=re.split(r'(\[[A-Za-z][A-Za-z0-9-]*\](?!\()|\*\*[^*]+\*\*|`[^`]+`|\*[^*]+\*)',s)
 out=[]
 for t in parts:
  if t.startswith('[') and t.endswith(']') and t[1:-1] in keys:out.append(r'\cite{'+t[1:-1]+'}')
  elif t.startswith('**') and t.endswith('**'):out.append(r'\textbf{'+inline(t[2:-2])+'}')
  elif t.startswith('`') and t.endswith('`'):out.append(r'\texttt{'+esc(t[1:-1])+'}')
  elif t.startswith('*') and t.endswith('*'):out.append(r'\emph{'+esc(t[1:-1])+'}')
  else:out.append(esc(t))
 return ''.join(out)
def convert(md,supp=False):
 lines=md.splitlines();out=[];i=0;pending=None;pending_label=None;table=0
 while i<len(lines):
  l=lines[i].strip()
  if not l:i+=1;continue
  if l.startswith('# '):i+=1;continue
  if l.startswith('## References'):break
  if l.startswith('**Table ') or l.startswith('**Main Table '):
   pending_label=re.match(r'^\*\*((?:Main )?Table [S0-9]+)',l).group(1);pending=re.sub(r'^\*\*(?:Main )?Table [S0-9]+[. ]*','',l).replace('**','');i+=1;continue
  if l.startswith('|'):
   rows=[]
   while i<len(lines) and lines[i].strip().startswith('|'):
    r=[x.strip() for x in lines[i].strip().strip('|').split('|')]
    if not all(re.fullmatch(r'[-: ]+',c) for c in r):rows.append(r)
    i+=1
   n=len(rows[0]);assert all(len(r)==n for r in rows)
   wide=(n>=4 or (not supp and pending_label=='Table 2')) and not (supp and pending_label in ('Table S9','Table S10'));env='table*' if wide else 'table';table+=1
   out.append(r'\begin{'+env+(r'}[ht]' if supp and pending_label in ('Table S9','Table S10') else r'}[t]'))
   if pending:
    if supp:
     out.append(r'\caption*{'+(pending_label+'. ')+inline(pending)+'}')
    else:out.append(r'\caption{'+inline(pending)+'}')
   else:out.append(r'\caption*{'+inline('Additional results.' if n<5 else 'Additional paired outcomes and source-review categories.')+'}')
   pending=None
   out += [r'\small',r'\begin{tabularx}{\linewidth}{@{}'+''.join(r'>{\raggedright\arraybackslash}X' for _ in range(n))+'@{}}',r'\toprule']
   out.append(' & '.join(r'\textbf{'+inline(c)+'}' for c in rows[0])+r' \\')
   out.append(r'\midrule')
   out += [' & '.join(inline(c) for c in r)+r' \\' for r in rows[1:]]
   out += [r'\bottomrule',r'\end{tabularx}',r'\end{'+env+'}'];continue
  if l.startswith('### '):
   t=l[4:];t=re.sub(r'^\d+\.\d+\s+','',t)
   out.append((r'\subsection*{' if supp else r'\subsection{')+inline(t)+'}');i+=1;continue
  if l.startswith('## '):
   t=l[3:];t=re.sub(r'^\d+\.\s+','',t)
   out.append((r'\section*{' if supp else r'\section{')+inline(t)+'}');i+=1;continue
  if l.startswith('- '):
   out.append(r'\begin{itemize}')
   while i<len(lines) and lines[i].strip().startswith('- '):out.append(r'\item '+inline(lines[i].strip()[2:]));i+=1
   out.append(r'\end{itemize}');continue
  paragraph=[l];i+=1
  while i<len(lines) and lines[i].strip() and not lines[i].startswith(('#','|','- ')):
   paragraph.append(lines[i].strip());i+=1
  out.append(inline(' '.join(paragraph))+'\n')
 return '\n'.join(out)
text=(P/'paper.md').read_text();abstract=text.split('## Abstract\n\n',1)[1].split('\n\n**Keywords:',1)[0]
body=text[text.index('## 1. Introduction'):].split('## References')[0]
header=r'''\documentclass[sigconf,anonymous,review,balance=false]{acmart}
\usepackage{tabularx}
\usepackage{booktabs}
\setlength{\emergencystretch}{2em}
\acmConference[ASIACCS '27]{ACM Asia Conference on Computer and Communications Security}{July 12--16, 2027}{Macau, China}
\acmYear{2027}
\copyrightyear{2027}
\acmDOI{}
\acmISBN{}
\setcopyright{acmcopyright}
\begin{document}
\title{Evaluating Payload-Dependent Task Loss in Adapted Agent Defenses}
\author{Anonymous Author(s)}
\begin{abstract}
'''
ccs=r'''
\end{abstract}
\begin{CCSXML}
<ccs2012><concept><concept_id>10002978.10003022</concept_id><concept_desc>Security and privacy~Software and application security</concept_desc><concept_significance>500</concept_significance></concept></ccs2012>
\end{CCSXML}
\ccsdesc[500]{Security and privacy~Software and application security}
\keywords{agent security evaluation, task availability, indirect prompt injection, enforcement policy, execution controls}
\maketitle
'''
s=header+inline(abstract)+ccs+convert(body)
s+=r'''\clearpage
\bibliographystyle{ACM-Reference-Format}
\nocite{*}
\bibliography{references}
\clearpage
\appendix
'''
for f in ['open_science.md','ethical_considerations.md']:
 s+=convert((P/f).read_text())+'\n'
s+='\n'+convert((P/'supplement.md').read_text(),supp=True)+r'\end{document}'+'\n'
(O/'paper.tex').write_text(s)
shutil.copyfile(P/'references.bib',O/'references.bib')
for f in ['acmart.cls','ACM-Reference-Format.bst']:
 if (P/'tools'/f).exists():shutil.copyfile(P/'tools'/f,O/f)
print('LaTeX generated',len(s),'bytes')
